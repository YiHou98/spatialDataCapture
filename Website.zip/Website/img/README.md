# Image Folder

## This is where you drop pngs, jpgs, etc

Delete this file before submitting.
