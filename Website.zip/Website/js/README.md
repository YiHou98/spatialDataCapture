# JavaScript Folder

## This is where you drop JavaScript files and libraries

Downloaded Libraries live in libs folder.  Your written scripts should live in the here.
Delete this file before submitting.
